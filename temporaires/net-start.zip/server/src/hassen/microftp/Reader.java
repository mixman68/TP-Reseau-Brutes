package hassen.microftp;

import hassen.microftp.common.Protocol;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Reader {

	private DataInputStream inputStream;
	private String text;
	private int type;
	private String filename;
	
	public Reader(InputStream inputStream) {
		this.inputStream = new DataInputStream (inputStream);
	}

	private int readInt () {
		try {
			return inputStream.readInt();
		} catch (IOException e) {
			return 0;
		}
	}

	private String readUTF () {
		try {
			return inputStream.readUTF();
		} catch (IOException e) {
			return "";
		}
	}

	public void receive() {
		text = readUTF ();
	}

	public String getText () {
		return text;
	}
	
	public int getType () {
		return type;
	}
	
	public String getFilename () {
		return filename;
	}
	
}
