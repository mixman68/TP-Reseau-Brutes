#include "StdAfx.h"
#include "Reader.h"


Reader::Reader(void)
{
}


Reader::~Reader(void)
{
}

void Reader::Reader_TCP (SOCKET s, string & Input) {
	char buffer[256];
	char *tmp = buffer;
	int bufferlen = sizeof(buffer);
	int len;
	do {
		len = recv (s, tmp, bufferlen, 0);
		tmp += len;
		bufferlen -= len;
	} while (len != SOCKET_ERROR && len != 0 && bufferlen != 0);
	if (len == SOCKET_ERROR)
		throw exception ("Reader Error");
	Input.assign (buffer, tmp - buffer);
}

void Reader::Reader_TCP (SOCKET s, string & Input,const int i) {
	char buffer[256];
	char *tmp = buffer;
	int bufferlen = sizeof(char)*i;
	int len;
	do {
		len = recv (s, tmp, bufferlen, 0);
		tmp += len;
		bufferlen -= len;
	} while (len != SOCKET_ERROR && len != 0 && bufferlen != 0);
	if (len == SOCKET_ERROR)
		throw exception ("Reader Error");
	Input.assign (buffer, tmp - buffer);
}

void Reader::Read(SOCKET s, PMessage & Message)
{
	Reader::Reader_TCP(s,Message.discriminant,1);

	//Impl�mentation de tous les types primitifs
	
	//Type string
	if(Message.discriminant.compare("t") == 0 )
	{
		string longueur;
		Reader::Reader_TCP(s,longueur,1);
		Reader::Reader_TCP(s,Message.msg,atoi(longueur.c_str()));
	}

}


