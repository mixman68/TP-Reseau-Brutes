package hassen.microftp;

import hassen.microftp.common.FileHelper;
import hassen.microftp.common.Protocol;

import java.io.IOException;
import java.net.Socket;

public class Session {

	private Socket connection;
	
	public Session (Socket connection) {
		this.connection = connection;
	}

	public boolean chat() {
		try {
			Reader reader = new Reader (connection.getInputStream());
			reader.receive ();
			String text = reader.getText();
			if (text.equals(Protocol.EXIT_TEXT)) return true;
			Writer writer = new Writer (connection.getOutputStream());
			writer.createText("Hello : "+text);
			writer.send ();
			return false;
		} catch (IOException e) {
			return true;
		}
	}

	public boolean ftp() {
		try {
			Writer writer = new Writer (connection.getOutputStream());
			Reader reader = new Reader (connection.getInputStream());
			reader.receive ();
			switch (reader.getType ()) {
			case Protocol.QUERY_DIR :
				break;
			case Protocol.QUERY_INFO : 
				break;
			case Protocol.QUERY_GET : 
				break;
			}
			writer.send ();
			return false;
		} catch (IOException e) {
			return true;
		}
	}

}
