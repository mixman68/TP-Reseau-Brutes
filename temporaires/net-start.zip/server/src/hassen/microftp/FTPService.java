package hassen.microftp;

import java.io.IOException;
import java.net.Socket;

public class FTPService extends Thread {

	private Socket connection;
	
	public FTPService(Socket connection) {
		this.connection = connection;
	}

	public void run() {
		Session session = new Session (connection);
		while (true) {
			if (session.ftp()) break;
		}
		try {
			if (connection != null) connection.close();
		} catch (IOException e) {
		}
	}

}
