package hassen.microftp;

import java.io.IOException;
import java.net.Socket;

public class ChatService extends Thread {

	private Socket connection;
	
	public ChatService(Socket connection) {
		this.connection = connection;
	}

	public void run() {
		Session session = new Session (connection);
		while (true) {
			if (session.chat()) break;
		}
		try {
			if (connection != null) connection.close();
		} catch (IOException e) {
		}
	}

}
