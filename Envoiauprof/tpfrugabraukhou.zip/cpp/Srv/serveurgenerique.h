#ifndef SERVEURGENERIQUE_H
#define SERVEURGENERIQUE_H


class Serveurgenerique
{
public:
	Serveurgenerique();
		virtual ~Serveurgenerique();
}
#endif