package hassen.microftp.common;

public interface Protocol {

	static final public int MICROFTP_PORT_ID = 7788;

	public static final Object EXIT_TEXT = "exit";

	static final public int QUERY_GET		= 0x0001;
	static final public int QUERY_DIR		= 0x0002;
	static final public int QUERY_INFO		= 0x0003;
	static final public int REPLY_FAILED	= 0x0004;
	static final public int REPLY_CONTENT	= 0x0005;
	static final public int REPLY_LIST		= 0x0006;
	static final public int REPLY_PROP		= 0x0007;

}
