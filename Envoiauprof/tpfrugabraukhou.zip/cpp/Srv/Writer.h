#ifndef WRITER_H
#define WRITER_H
#include "Charac.h"

class Writer
{
public:
	Writer(void);
	~Writer(void);
	static void Writer_TCP (SOCKET, const string &);
	static void Writer_Text(SOCKET, const string &);
	static void Writer_Prim(SOCKET, const Charac &);
};
#endif
