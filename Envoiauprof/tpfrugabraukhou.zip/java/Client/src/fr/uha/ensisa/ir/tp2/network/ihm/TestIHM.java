package fr.uha.ensisa.ir.tp2.network.ihm;

public class TestIHM {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BruteIHM();

	}

}
