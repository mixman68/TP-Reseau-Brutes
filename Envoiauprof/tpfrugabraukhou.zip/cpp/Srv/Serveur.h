#ifndef SERVEUR_H
#define SERVEUR_H

class Serveur
{
public:
	Serveur(void);

	static SOCKET Create_Socket_Server_TCP(short);

	static void Reader_TCP (SOCKET s, string & Input);
	static void Writer_TCP (SOCKET s, const string &);

	static void Serveur::Service(SOCKET);

	virtual ~Serveur(void);
};
#endif

