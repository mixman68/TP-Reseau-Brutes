// stdafx.cpp�: fichier source incluant simplement les fichiers Include standard
// clientIHM.pch repr�sente l'en-t�te pr�compil�
// stdafx.obj contient les informations de type pr�compil�es

#include "stdafx.h"


