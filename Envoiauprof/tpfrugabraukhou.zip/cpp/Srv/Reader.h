#ifndef READER_H
#define READER_H

#include "StdAfx.h"

class Reader
{
public:
	Reader(void);
	~Reader(void);
	static void Reader_TCP (SOCKET, string &);
	static void Reader_TCP (SOCKET, string &, const int);
	static void Read(SOCKET, PMessage &);
};

#endif

