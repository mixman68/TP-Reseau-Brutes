#include "StdAfx.h"
#include "Writer.h"


Writer::Writer(void)
{
}


Writer::~Writer(void)
{
}

void Writer::Writer_TCP (SOCKET s, const string & text) {
	int len = send (s, text.data(), text.size(), 0);
	if (len == SOCKET_ERROR)
		throw exception ("Writer Error");
}

//Une m�thode de classe par type primitif

void Writer::Writer_Text(SOCKET s, const string & msg)
{
	int lenght = msg.size();
    stringstream buf;//create a stringstream
    buf << lenght;//add number to the stream

	const string discriminant = "t";

	Writer::Writer_TCP(s,discriminant+buf.str()+msg);
}
