package hassen.microftp;

import java.net.ServerSocket;
import java.net.Socket;

import hassen.microftp.common.Protocol;

public class Main {

	private ServerSocket server = null;
	
	public void chatServer () {
		try {
			server = new ServerSocket (Protocol.MICROFTP_PORT_ID);
			while (true) {
				Socket connection = server.accept();
				ChatService service = new ChatService (connection);
				service.start ();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void ftpServer () {
		try {
			server = new ServerSocket (Protocol.MICROFTP_PORT_ID);
			while (true) {
				Socket connection = server.accept();
				FTPService service = new FTPService (connection);
				service.start ();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Main m = new Main ();
		m.chatServer();
//		m.ftpServer();
	}

}
